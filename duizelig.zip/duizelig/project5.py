while True:
    print("................................")
    answer = int(input("Schrif een nummer:"))
    print("................................")
    quit = 5
    if answer == quit:
        print("Goed gedaan!")
        break
    else:
        print("..........................")
        print("fout! doe het nog een keer")
        print("..........................")
