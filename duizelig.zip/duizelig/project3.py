a = 20
while a < int(51):
    print(a)
    a = a + 2
    if a == 51:
        break