a = 0
while a < 24:
    if a < 12:
        print(a , "am")
    else:
        print(a , "pm")
        if a == 23 :
            break
    a = a + 1